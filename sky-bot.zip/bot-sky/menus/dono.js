const menudono = (prefix) => {
	
	
// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 	

return `
	
╭───────────────
╎
┝ ⎙  Menu Dono
╎
╎⩺  Info de como configurar o Bot> Digite: 
╎
╎⩺  ${prefix}configurar-bot
╎
╰───────────────
╎
╎⩺ ${prefix}fotomenu (marca-img)
╎⩺ ${prefix}blockcmd  (cmd)
╎⩺ ${prefix}unblockcmd (cmd)
╎⩺ ${prefix}legendabv (oq qr)
╎⩺ ${prefix}legendasaiu (oq qr)
╎⩺ ${prefix}legendasaiu2 (oq qr)
╎⩺ ${prefix}legendabv2 (oq qr)
╎⩺ ${prefix}prefixo_tipo2 simbolo
╎⩺ ${prefix}prefixo_tipo_off
╎⩺ ${prefix}fundobemvindo (marcar-img)
╎⩺ ${prefix}fundosaiu (marcar-img)
╎⩺ ${prefix}serpremium
╎⩺ ${prefix}listabt
╎⩺ ${prefix}listagp
╎⩺ ${prefix}antipalavrão 1 / 0
╎⩺ ${prefix}antiligar 1 / 0
╎⩺ ${prefix}addpalavra (palavrão)
╎⩺ ${prefix}delpalavra (palavrão)
╎⩺ ${prefix}ativo
╎⩺ ${prefix}ausente (fale-oq-faz)
╎⩺ ${prefix}delpremium @(marca)
╎⩺ ${prefix}addpremium @(marca)
╎⩺ ${prefix}clonar [@] (rouba ft de prf)
╎⩺ ${prefix}fotobot (img, = foto do BT)
╎⩺ ${prefix}descriçãogp (digite-algo)
╎⩺ ${prefix}limpar (limpa tds conversas)
╎⩺ ${prefix}block [@] (bloq de usar cmds) 
╎⩺ ${prefix}unblock [@] (desbloquear) 
╎⩺ ${prefix}setprefix  (prefixo-novo)
╎⩺ ${prefix}bangp
╎⩺ ${prefix}unbangp
╎⩺ ${prefix}dono2 @marca
╎⩺ ${prefix}dono3 @marca
╎⩺ ${prefix}dono4 @marca
╎⩺ ${prefix}dono5 @marca
╎⩺ ${prefix}bcgp (TM-PRA-PV-MEMBROS)
╎
╰─────────────╯
`

}
exports.menudono = menudono







