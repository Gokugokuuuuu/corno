const menu = (prefix, NomeDoBot) => {
  
// NÃO APAGUE ESSE ${NickDono} nem 
//${numerodn} nem ${NomeDoBot} nem ${prefix} só se quiser apagar completo, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.  
  
return `​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
╭───────────────
╎
┝〢 ${NomeDoBot} 
╎
╰─────────────╯

MINHA FUNCIONALIDADE É MANTER VIGENTE AS REGRAS DO GRUPO, E AUXILIAR OS MEMBROS NO SUPORTE.

TENHO VARIAS FUNÇÕES QUE SERA DESCRITAS E USADAS PARA UM BEM COMUM.

VOU LISTAR ALGUNS NAO ESQUEÇA DE VER O COMANDO TEM OU NAO (/) SE TIVER BARAR PRECISA CONSTAR NO TEXTO:

╭───────────────
╎
┝〢 FUNC. SSH
╰─────────────╯

${prefix}sshgratis
${prefix}sshlista


${prefix}ping
${prefix}blockcmd
${prefix}unblockcmd
${prefix}avalie
${prefix}bug
${prefix}sugestao
${prefix}bc
${prefix}igstalk
${prefix}celular
${prefix}gimage
${prefix}join
${prefix}limpar
${prefix}clearchat
${prefix}limparchat
${prefix}limparmsg
${prefix}efeitos
${prefix}owner
${prefix}odono
${prefix}dono
${prefix}infodono
${prefix}alteradores
${prefix}menupremium
${prefix}menuprem
${prefix}configurar-bot
${prefix}comandos-script
${prefix}hospedar
${prefix}destrava
${prefix}tabela
${prefix}destrava2
${prefix}infovotação
${prefix}infovotacao
${prefix}infobemvindo
${prefix}infobv
${prefix}ausente
${prefix}ativo
${prefix}nick
${prefix}gerarnick
${prefix}fazernick
${prefix}chance
${prefix}inativos
${prefix}rankativo
${prefix}rankativos
${prefix}rankinativo
${prefix}rankinativos
${prefix}checkativo

╭───────────────
╎
┝〢 ANTIS...
╰─────────────╯

${prefix}antictt
${prefix}anticontato
${prefix}anticatalogo
${prefix}anticatalg
${prefix}antifake
${prefix}antiloc
${prefix}antidocumento
${prefix}antidoc
${prefix}antiimg
${prefix}antisticker
${prefix}antinotas
${prefix}antivideo
${prefix}antiaudio
${prefix}limitecaracteres
${prefix}limiteflood
${prefix}antiporno
${prefix}antipalavrão
${prefix}antipalavrao
${prefix}antipalavra
${prefix}antilinkhard
${prefix}antilink
${prefix}autofigu
${prefix}antilinkgp

╭───────────────
╎
┝〢 FUNC. GP
╰─────────────╯

${prefix}bemvindo
${prefix}welcome
${prefix}bemvindo2
${prefix}nomegp
${prefix}descgp
${prefix}descriçãogp
${prefix}setfotogp
${prefix}addpalavra
${prefix}delpalavra
${prefix}listapalavrão
${prefix}listpalavra
${prefix}legendabv
${prefix}legendasaiu
${prefix}legendabv2
${prefix}legendasaiu2
${prefix}deletar
${prefix}fundobemvindo
${prefix}fundobv
${prefix}fundosaiu
${prefix}menuadm
${prefix}cmdmem
${prefix}fotogp
${prefix}linkgp
${prefix}linkgroup
${prefix}grupo
${prefix}grupoinfo
${prefix}infogrupo
${prefix}infogp
${prefix}gpinfo
${prefix}regras
${prefix}totag
${prefix}cita
${prefix}hidetag
${prefix}marcar
${prefix}marcar2
${prefix}marcarwa
${prefix}reviver
${prefix}add
${prefix}sairgp
${prefix}seradm
${prefix}sermembro
${prefix}bann
${prefix}ban
${prefix}apresentar
${prefix}apr
${prefix}papof
${prefix}regraspp
${prefix}digt
${prefix}listagp
${prefix}addautorm
${prefix}addautoban
${prefix}listanegra
${prefix}delremover
${prefix}delautorm
${prefix}delautoban
${prefix}tirardalista
${prefix}nome-bot
${prefix}nick-dono
${prefix}numero-dono
${prefix}prefixo-bot
${prefix}a_autorepo
${prefix}d_autorepo
${prefix}prefixo_tipo2
${prefix}prefixo_tipo_off
${prefix}fotomenu
${prefix}fundomenu
${prefix}nomegp
${prefix}fotobot
${prefix}clonar
${prefix}bcgp
${prefix}bcgc
${prefix}getquoted
${prefix}admins
${prefix}listadmins
${prefix}listaadmins
${prefix}aviso_gp
${prefix}criartabela
${prefix}tabelagp
${prefix}alugado
${prefix}tempo-fgp
${prefix}fechar-gp
${prefix}iptv
${prefix}net
${prefix}menu
${prefix}help
${prefix}comandos
${prefix}menu2
${prefix}film
${prefix}sendimage
${prefix}sendvideo
${prefix}dono
${prefix}criador
`
}

exports.menu = menu

// NÃO APAGUE ESSE ${NickDono} nem 
//${numerodn} nem ${NomeDoBot} nem ${prefix} só se quiser apagar completo, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.
